using UnityEngine;

public class SwordController : MonoBehaviour
{
    public int swordPoints;  // Valor de la espada (bronce, plata, oro)

    public int GetPoints()
    {
        return swordPoints;
    }
}
