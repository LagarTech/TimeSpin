using System.Collections;
using System.Collections.Generic;
using System.Runtime.ConstrainedExecution;
using TMPro;
using Unity.Netcode;
using UnityEngine;

public class GridManager : NetworkBehaviour
{
    public static GridManager Instance;

    // Variable que controla el flujo del juego
    public bool runningGame = true;
    // Variable que gestiona el n�mero de jugadores
    private int _numPlayers;

    // Dimensiones del tablero
    private const int COLUMNS = 13;
    private const int ROWS = 9;
    // Casillas del tablero, organizadas en una matriz bidimensional
    private Tile[,] _gridTiles = new Tile[COLUMNS, ROWS];
    private float tileSize = 1f;
    // Lista de casillas no caminables de todo el mapa
    [SerializeField] private List<Vector2Int> _nonWalkableTiles;

    // Temporizador del juego
    [SerializeField] private TMP_Text _timerText;
    private float _remainingTime = 120f; // El tiempo de juego son 2 minutos (120 segundos)

    // Gesti�n de la aparici�n aleatoria de pinchos
    // Lista de todas las casillas con pinchos
    [SerializeField] private List<GameObject> _spikesList;
    // Lista para generar la aparici�n aleatoria de los pinchos
    private List<int> _randomSpikesSpawn = new List<int>();
    // N�mero total de casillas que tendr�n pinchos
    private const int NUM_SPIKES_TILES = 10;
    // Tiempo que tiene que transcurrir para que aparezcan los siguientes pinchos
    private float _spikesTime = 20f; // En un principio, se esperan 20 segundos para empezar a generar pinchos
    // N�mero de casillas con pinchos
    private int _numSpikes = 0;

    // Gesti�n de la aparici�n de momias
    // Prefab de la momia
    [SerializeField] private GameObject _mummy;
    // Tiempo que tiene que transcurrir para que se genere una nueva momia
    private float _mummyTime = 0f;

    private void Awake()
    {
        Instance = this;
    }

    private void Start()
    {
        // Se genera el tablero, la l�gica s�lo se almacena en el servidor
        if(Application.platform == RuntimePlatform.LinuxServer)
        {
            GenerateGrid();
            // Se prepara la gesti�n aleatoria de los pinchos en el servidor
            PrepareSpikesSpawn();
        }
    }

    private void Update()
    {
        if (!runningGame) return;

        // GESTI�N DEL TIEMPO RESTANTE
        if(_remainingTime > 0f)
        {
            // Disminuir el tiempo restante
            _remainingTime -= Time.deltaTime;
            // Se actualiza el temporizador s�lo en el cliente
            if(Application.platform != RuntimePlatform.LinuxServer)
            {
                UpdateTimer();
            }
        }
        else
        {
            _remainingTime = 0f;
            // Se actualiza el temporizador s�lo en el cliente
            if (Application.platform != RuntimePlatform.LinuxServer)
            {
                UpdateTimer();
            }
            // Se indica que el juego ha finalizado
            runningGame = false;
            GameOver();
            return;
        }

        // APARICI�N DE PINCHOS
        // Esto ser realizar� en el servidor, que es el que almacena la l�gica, y en el cliente, para hacerlo visible
        _spikesTime -= Time.deltaTime;
        if(_spikesTime < 0f)
        {
            _spikesTime = 10f; // Entre apariciones se deja un tiempo de 10 segundos
            SpawnSpikes();
        }

        // GENERACI�N DE MOMIAS
        // �nicamente en el servidor, se spawnear�n directamente en el cliente
        if(Application.platform == RuntimePlatform.LinuxServer)
        {
            _mummyTime -= Time.deltaTime;
            if(_mummyTime < 0f)
            {
                if (IsServer)  // Solo el servidor puede spawnear objetos
                {
                    // Instancia el objeto en el servidor
                    GameObject _mummyObj = Instantiate(_mummy, Vector3.zero, Quaternion.identity);

                    // Lo registramos en la red para sincronizarlo con los clientes
                    _mummyObj.GetComponent<NetworkObject>().Spawn();
                    _mummyTime = 30f;
                }
            }
        }

        // CONTROL DEL N�MERO DE JUGADORES
        // �nicamente en el servidor
        if(Application.platform == RuntimePlatform.LinuxServer)
        {
            _numPlayers = GameObject.FindGameObjectsWithTag("Player").Length;
            // Si s�lo queda un jugador, se termina el juego
            if(_numPlayers == 1)
            {
                runningGame = false;
                GameOver();
            }
        }

    }

    #region Grid

    private void GenerateGrid()
    {
        for(int x = 0; x < COLUMNS; x++)
        {
            for(int z = 0; z < ROWS; z++)
            {
                // Primero se define el centro de la casilla en la que se encuentra
                Vector3 tileCenter = new Vector3((x * tileSize) + tileSize / 2, 0, - ((z * tileSize) + tileSize / 2));

                // Se crea la casilla y se a�ade a la matriz
                _gridTiles[x,z] = new Tile(x, z, tileCenter);
            }
        }

        GenerateNonWalkableTiles();
    }

    private void GenerateNonWalkableTiles()
    {
        // Se recorren todas las coordenadas de las casillas no caminables, para marcarlas en el tablero
        foreach(Vector2Int tile in _nonWalkableTiles)
        {
            _gridTiles[tile.x, tile.y].MakeNonWalkable();
        }
    }

    public Tile GetTile(int x, int z)
    {
        // Comprobar si las coordenadas est�n dentro de los l�mites del tablero
        if (x < 0 || x >= COLUMNS || z < 0 || z >= ROWS)
        {
            // Si est�n fuera de los l�mites, devolver null
            return null;
        }

        // Si est�n dentro de los l�mites, devolver la casilla correspondiente
        return _gridTiles[x, z];
    }

    public Tile[] GetWalkableNeighbours(Tile currentTile)
    {
        List<Tile> walkableNeighbours = new List<Tile>();

        // Obtener las coordenadas de la casilla actual
        Vector2Int currentPos = new Vector2Int(currentTile.xTile, currentTile.zTile);

        // Definir los posibles desplazamientos (arriba, abajo, izquierda, derecha)
        Vector2Int[] directions = new Vector2Int[]
        {
        new Vector2Int(0, -1),  // Arriba
        new Vector2Int(0, 1), // Abajo
        new Vector2Int(-1, 0), // Izquierda
        new Vector2Int(1, 0)   // Derecha
        };

        // Iterar sobre cada direcci�n y obtener las casillas vecinas
        foreach (Vector2Int dir in directions)
        {
            // Obtener las coordenadas de la casilla vecina
            Vector2Int neighbourPos = currentPos + dir;

            // Obtener la casilla vecina del GridManager (o tu gestor de tablero)
            Tile neighbourTile = GridManager.Instance.GetTile(neighbourPos.x, neighbourPos.y);

            // Si la casilla vecina existe y es caminable, a�adirla a la lista
            if (neighbourTile != null && neighbourTile.isWalkable)
            {
                walkableNeighbours.Add(neighbourTile);
            }
        }

        // Devolver la lista de vecinos caminables como un array
        return walkableNeighbours.ToArray();
    }
    #endregion

    #region Timer

    private void UpdateTimer()
    {
        // Calcular minutos y segundos
        int displayMinutes = Mathf.FloorToInt(_remainingTime / 60);
        int displaySeconds = Mathf.FloorToInt(_remainingTime % 60);

        // Actualizar el texto del TMP para que muestre el tiempo restante
        _timerText.text = string.Format("{0:00}:{1:00}", displayMinutes, displaySeconds);
    }

    #endregion

    #region Spikes

    private void PrepareSpikesSpawn()
    {
        // Al ser un total de 10 pinchos, se genera una lista de 10 elementos
        for(int i = 0; i < NUM_SPIKES_TILES; i++)
        {
            _randomSpikesSpawn.Add(i);
        }
        // Para garantizar que aparezcan de forma aleatoria, es decir, en cada partida con un orden distinto,
        // se utiliza el algoritmo de Fisher - Yates, con coste O(N)
        int n = _randomSpikesSpawn.Count;
        for(int i = n - 1; i > 0; i--)
        {
            int j = Random.Range(0, i + 1); // Usamos UnityEngine.Random para generar un n�mero aleatorio
            // Intercambiar los elementos en i y j
            int temp = _randomSpikesSpawn[i];
            _randomSpikesSpawn[i] = _randomSpikesSpawn[j];
            _randomSpikesSpawn[j] = temp;
        }
    }

    private void SpawnSpikes()
    {
        // Primero se realiza la l�gica en el servidor
        int randomSpike = _randomSpikesSpawn[_numSpikes];
        // Se activan los pinchos de la casilla que toque seg�n el orden aleatorio
        _spikesList[randomSpike].SetActive(true);
        // Se obtiene la posici�n global de dicha casilla
        Vector3 spikesPos = _spikesList[_randomSpikesSpawn[_numSpikes]].transform.position;
        // Se pasa de dichas coordenadas a las locales del escenario
        Vector2 spikesTilePos = new Vector2(spikesPos.x - 0.5f, -(spikesPos.z + 0.5f));
        // Se utilizan dichas coordenadas de la casilla para marcarla como no caminable
        GetTile((int)spikesTilePos.x, (int)spikesTilePos.y).MakeNonWalkable();
        // Se indica que se ha generado una casilla m�s con pinchos
        _numSpikes++;
        // Una vez hecho, se activan los pinchos en los clientes
        SpawnSpikesClientRpc(randomSpike);
    }

    [ClientRpc]
    private void SpawnSpikesClientRpc(int idSpike)
    {
        // Se hace visible en los clientes la trampa que toque, en base a lo realizado en el servidor
        _spikesList[idSpike].SetActive(true);
    }

    #endregion

    private void GameOver()
    {

    }
}
