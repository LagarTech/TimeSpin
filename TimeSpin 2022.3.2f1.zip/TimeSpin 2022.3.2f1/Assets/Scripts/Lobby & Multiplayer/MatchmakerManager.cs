using System.Collections;
using System.Collections.Generic;
using System.Threading.Tasks;
using Unity.Collections;
using Unity.Netcode;
using Unity.Netcode.Transports.UTP;
using Unity.Services.Authentication;
using Unity.Services.Matchmaker;
using Unity.Services.Matchmaker.Models;
using UnityEngine;

public class MatchmakerManager : NetworkBehaviour
{
    public static MatchmakerManager Instance;

    private string _currentTicket;
    private string _serverIP;
    private ushort _serverPort;

    private bool _isDeallocating = false;
    private bool _deallocatingCancellationToken = false;

    public string GetServerIP() { return _serverIP; }
    public ushort GetServerPort() { return _serverPort; }

    private void Awake()
    {
        if(Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(this);
        }
    }

    private void Update()
    {
        // Este c�digo solo se ejecuta en el servidor, ya que es el encargado de desasignarlo
        if(NetworkManager.Singleton.IsServer && Application.platform == RuntimePlatform.LinuxServer)
        {
            // Si no hay ning�n cliente conectado se detiene el servidor
            if(NetworkManager.Singleton.ConnectedClients.Count == 0 && !_isDeallocating)
            {
                _isDeallocating = true;
                _deallocatingCancellationToken = false;
                DeallocateServer();
            }
            if(NetworkManager.Singleton.ConnectedClients.Count != 0)
            {
                _isDeallocating = false;
                _deallocatingCancellationToken = true;
            }

        }
    }

    private void OnApplicationQuit()
    {
        // Verifica si el NetworkManager es el servidor y est� ejecut�ndose en Linux
        if (NetworkManager.Singleton.IsServer && Application.platform == RuntimePlatform.LinuxServer)
        {
            // Verifica si hay clientes conectados
            if (NetworkManager.Singleton.ConnectedClients.Count > 0)
            {
                // Desconecta a todos los clientes
                foreach (var client in NetworkManager.Singleton.ConnectedClients)
                {
                    NetworkManager.Singleton.DisconnectClient(client.Key);
                }
            }
            // Finaliza el NetworkManager
            NetworkManager.Singleton.Shutdown();
        }
    }

    // Funci�n para realizar el emparejamiento del creador de la sala con el servidor
    public async Task FirstServerJoin()
    {
        // Se configura la petici�n del ticket
        CreateTicketOptions createTicketOptions = new CreateTicketOptions("JoinServerQueue");
        List<Player> players = new List<Player> { new Player(AuthenticationService.Instance.PlayerId) };
        CreateTicketResponse createTicketResponse = await MatchmakerService.Instance.CreateTicketAsync(players, createTicketOptions);

        _currentTicket = createTicketResponse.Id;
        Debug.Log("Ticket created: " + _currentTicket);

        // Despu�s, se comprueba el estado del ticket
        while (true)
        {
            TicketStatusResponse ticketStatusResponse = await MatchmakerService.Instance.GetTicketAsync(_currentTicket);
            // Se comprueba si su estado ha cambiado 
            if(ticketStatusResponse.Type == typeof(MultiplayAssignment))
            {
                MultiplayAssignment multiplayAssignment = (MultiplayAssignment) ticketStatusResponse.Value;
                // En funci�n del estado que sea se hace una acci�n u otra
                if (multiplayAssignment.Status == MultiplayAssignment.StatusOptions.Found)
                {
                    UnityTransport transport = NetworkManager.Singleton.GetComponent<UnityTransport>();
                    // Se obtienen los datos de la conexi�n
                    _serverIP = multiplayAssignment.Ip;
                    _serverPort = ushort.Parse(multiplayAssignment.Port.ToString());
                    transport.SetConnectionData(_serverIP, _serverPort);

                    NetworkManager.Singleton.StartClient();
                    Debug.Log("Server found");
                    return;
                }
                else if (multiplayAssignment.Status == MultiplayAssignment.StatusOptions.Timeout)
                {
                    Debug.Log("Match timeout");
                    return;
                }
                else if (multiplayAssignment.Status == MultiplayAssignment.StatusOptions.Failed)
                {
                    Debug.Log("Match failed: " + multiplayAssignment.Status + "  " + multiplayAssignment.Message);
                    return;
                }
                else if (multiplayAssignment.Status == MultiplayAssignment.StatusOptions.InProgress)
                {
                    Debug.Log("Match in progress");
                }
            }

            await Task.Delay(1000);
        }
    }

    // Funci�n para desasignar un servidor
    private async void DeallocateServer()
    {
        await Task.Delay(60 * 1000);

        if(!_deallocatingCancellationToken)
        {
            Application.Quit();
        }
    }

}
