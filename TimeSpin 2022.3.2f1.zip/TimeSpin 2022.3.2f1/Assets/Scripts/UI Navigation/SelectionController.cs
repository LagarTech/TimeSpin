using System.Collections;
using System.Collections.Generic;
using Unity.Services.Lobbies.Models;
using UnityEngine;

public class SelectionController : MonoBehaviour
{
    public static SelectionController instance;
    // Variables que almacenan la informaci�n con la que se caracteriza un jugador en l�nea
    [SerializeField] private int _selectedCharacter;
    [SerializeField] private string _namePlayer;

    private void Awake()
    {
        if(instance == null)
        {
            instance = this;
        }
        else
        {
            Destroy(this);
        }
    }
    // Funci�n para modificar el personaje escogido
    public void ModifyCharacter(int newCharacter)
    {
        _selectedCharacter = newCharacter;
    }

    // Funci�n para cambiar el nombre del jugador
    public void ModifyName(string newName)
    {
        _namePlayer = newName;
    }

    // Funci�n que devuelve un jugador con sus datos para incluirlo en el lobby
    public Player GetPlayer()
    {
        // Este jugador se caracteriza por un nombre y un personaje seleccionado
        return new Player
        {
            Data = new Dictionary<string, PlayerDataObject>
            {
                // Solo almacenamos el nombre del jugador, junto con el color del coche que lleve
                { "Name", new PlayerDataObject(PlayerDataObject.VisibilityOptions.Member, _namePlayer) },
                { "Character", new PlayerDataObject(PlayerDataObject.VisibilityOptions.Member, _selectedCharacter.ToString()) }
            }
        };
    }



}
